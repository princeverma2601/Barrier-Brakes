<script src="../js/jquery.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/all.min.js"></script>
<script type="text/javascript" src="../js/adminajaxrequest.js"></script>
</body>
</html>