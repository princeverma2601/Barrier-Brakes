<?php
include('./MainInclude/Header.php')
?>
            <h1> Contact Us</h1>
        </section>

        <section class="location">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3507.959036703751!2d77.5820091147173!3d28.450651199041012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cbf94deb6bc39%3A0x7ba6bedc9a2b537f!2sBennett%20University%20(Times%20of%20India%20Group)!5e0!3m2!1sen!2sin!4v1676850244841!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

        </section>

        <section class="contact-us" style="margin: auto; width: 25%;">
            <div class="rows" >
                <div class="contact-col">
                    <div>
                        <i class="fa fa-home"></i>
                        <span>
                            <h5>Dabra road,Bennett University</h5>
                            <p>Greater Noida,UP,INDIA</p>
                        </span>

                    </div>
                    <div>
                        <i class="fa fa-phone"></i>
                        <span>
                            <h5>+91 9897335584,+91 8488419919 </h5>
                            <p>Monday to Saturday, 10AM to 7PM</p>
                        </span>

                    </div>
                <div>
                    <i class="fa fa-envelope-o"></i>
                    <span>
                        <h5>prakharag2001@gmail.com</h5>
                        <p>Email us your query</p>
                    </span>
                </div>
            </div>
                <!--<div class="contact-col">

                    <form action="form-handler.php" method="post">
                        <input type="text" name="name" placeholder="Enter Your name" required>
                        <input type="email" name ="email" placeholder="Enter email Address" required>
                        <input type="text" name ="subject" placeholder="Enter Your subject" required>
                        <textarea rows="8" name = "message" placeholder="Messege" required></textarea>
                        <button type="submit" class ="hero-btn red-btn">Send Messege</button>

                    </form>


                </div>-->
            </div>
        </section>
        <?php
include('./MainInclude/Footer.php')
?>
