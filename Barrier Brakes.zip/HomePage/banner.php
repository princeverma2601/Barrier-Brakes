<section class="cta">
            <h1>Enroll For Our Various Online Courses<br>Anywhere From The World</h1>
            <a href="./contact.php" class=" hero-btn" style="text-decoration: none; color: #fff; border-radius: 25px;">CONTACT US</a>
        </section>